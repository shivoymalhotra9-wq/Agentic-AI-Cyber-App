# PhishSquad labeling first pass

925 emails labeled using LABELING_GUIDE.md. This is an AI first pass, not a human-reviewed or frozen answer key.

| Label | All emails | Included in benchmark |
|---|---:|---:|
| phishing | 341 | 315 |
| bec | 2 | 2 |
| spam | 194 | 185 |
| legitimate | 388 | 371 |

Confidence: 617 high, 217 medium, 91 low.
52 duplicate copies excluded; 873 rows retained for benchmark eligibility. All 925 source rows and emails remain present.
359 rows in the priority human review queue. The guide still calls for human review of every row.

## Method

Email paths were shuffled and replaced with neutral numeric identifiers for first-pass judgment. Source categories, collection origins, manifest notes, and filenames were not used as labeling evidence. MIME text and HTML were decoded locally; links were read as strings without fetching or resolving them. Initial reviews used compact decoded excerpts, with longer reads for ambiguous and flagged cases, plus a full-text search for missed fraud cues. Attached binaries were not executed or analyzed; attachment judgments use filenames and email context. Encoded JavaScript strings in two adult advertisements were decoded as data without executing the email.

Labels, maliciousness, confidence, evidence, labeler and benchmark inclusion are populated. Existing source notes are preserved, with AI notes appended after // . second_label remains blank. No human pilot, second-person agreement check, or freeze has been claimed.

Duplicate review uses whitespace/case normalization and replacement of URLs, email addresses and numbers, followed by exact matches or >=0.93 character similarity with substantial token overlap. Matches based solely on shared boilerplate or URL-only content were rejected. This is a conservative duplicate screen; more campaign variants may require manual grouping. duplicate-exclusions.csv identifies every excluded copy and retained counterpart.

## Interpretation notes for reviewers

- Ordinary commercial purchases and lead-generation forms do not automatically make advertising phishing. Credential requests, impersonation, fraudulent payout stories or suspicious executable attachments do.
- Known-contact money diversion takes precedence as BEC. Both CEO wire-transfer examples are labeled BEC.
- Upfront cash-chain/pyramid programs are phishing; evidence explicitly mentions advance-fee.
- Generic prize/reward marketing without a fee, login demand or persuasive impersonation evidence is spam. Counterfeit brand reward notices with deceptive destinations are phishing, usually medium confidence when the downstream payload is not visible.
- Real, consistent service newsletters and expected company marketing follow rule 6, even if promotional or gambling-related. Subscription status cannot be independently verified from these samples.
- Routine HR PDFs, vendor documents, certificate renewal notices, and body-only shells often lack enough context to prove fraud. Low-confidence labels are provisional.
- Sextortion demanding money is phishing under the guide's broad deception-for-money definition.

## Extractor issues

25 rows carry extractor_empty_body flags. 23 have readable text recovered from raw MIME; remaining rows retain useful subject, sender, link or attachment evidence. None was excluded solely because of that flag. extractor-bugs.csv preserves these cases for follow-up.

## Files

manifest.csv: all original columns and rows, now labeled.
labels.jsonl: AI judgments in guide format.
human-review-queue.csv: low/medium confidence, category disagreements, and BEC cases.
duplicate-exclusions.csv: exclusion audit.
extractor-bugs.csv: extractor flag audit.

Original source licenses remain unchanged. Review licensing before redistribution.
