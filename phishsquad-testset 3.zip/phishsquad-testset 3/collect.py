"""Collect the PhishSquad raw test set (unlabeled) from public sources.
Reproducible: fixed seed. Sources are cloned from GitHub first (see SOURCES.md)."""
import os, re, csv, random, hashlib, email, shutil
from email import policy
random.seed(20260930)
OUT = 'phishsquad-testset'
shutil.rmtree(OUT, ignore_errors=True)

def parse(raw):
    return email.message_from_bytes(raw, policy=policy.default)

def subj(m):
    try: return str(m.get('Subject', '') or '')
    except Exception: return ''

def norm(s):
    s = re.sub(r'phishing@pot', '', s, flags=re.I)
    s = re.sub(r'[\d#]+', '0', s.lower())
    return re.sub(r'\W+', ' ', s).strip()[:60]

def pick(files, n, allow_empty_subject=False):
    random.shuffle(files)
    seen_subj, seen_hash, out = set(), set(), []
    for path in files:
        raw = open(path, 'rb').read()
        h = hashlib.sha1(raw).hexdigest()
        if h in seen_hash: continue
        try: m = parse(raw)
        except Exception: continue
        if not m.get('From'): continue
        s = norm(subj(m))
        if (not s and not allow_empty_subject) or s in seen_subj: continue
        seen_hash.add(h); seen_subj.add(s)
        out.append((path, raw, m))
        if len(out) == n: break
    return out

manifest = []
def save(cat, items, source, license_):
    os.makedirs(f'{OUT}/{cat}', exist_ok=True)
    for i, (path, raw, m) in enumerate(items, 1):
        fid = f'{cat}-{i:03d}'
        open(f'{OUT}/{cat}/{fid}.eml', 'wb').write(raw)
        manifest.append(dict(id=fid, source_category=cat, source=source,
            original_file=path.split('/', 1)[1] if '/' in path else path,
            date=str(m.get('Date', '') or ''), from_=str(m.get('From', '') or '')[:120],
            subject=subj(m)[:150], license=license_, label='', label_notes=''))

ls = lambda d: [os.path.join(d, f) for f in sorted(os.listdir(d)) if not f.startswith('cmds')]

# Phishing: recent honeypot captures, spread evenly over 2023-2026
pot = ls('phishing_pot/email')
by_year = {}
for p in pot:
    m = parse(open(p, 'rb').read()); y = re.search(r'20(2[3-6])', str(m.get('Date', '')))
    if y: by_year.setdefault(y.group(0), []).append(p)
phish = []
for y in sorted(by_year): phish += pick(by_year[y], 150 // len(by_year) + (1 if y == '2023' else 0) + (1 if y == '2024' else 0))
save('phishing', phish[:150], 'phishing_pot (rf-peixoto, GitHub)', 'CC BY-NC 4.0')

# Spam: SpamAssassin spam + spam_2
save('spam', pick(ls('SpamAssassin/spam') + ls('SpamAssassin/spam_2'), 150), 'SpamAssassin public corpus', 'SpamAssassin corpus terms (research use)')

# Legitimate: 100 ordinary + 50 "hard ham" (real marketing mail that looks spammy)
legit = pick(ls('SpamAssassin/easy_ham') + ls('SpamAssassin/easy_ham_2'), 100) + pick(ls('SpamAssassin/hard_ham'), 50)
save('legitimate', legit, 'SpamAssassin public corpus (easy_ham 100 / hard_ham 50)', 'SpamAssassin corpus terms (research use)')

# Trick set: all 275 IWSPA adversarial emails (body only -> minimal wrapper)
os.makedirs(f'{OUT}/tricks', exist_ok=True)
csv.field_size_limit(10**8)
rows = list(csv.DictReader(open('IWSPA-2023-Adversarial-Synthetic-Dataset/Adversarial/adversarial_dataset.csv', encoding='utf-8', errors='replace')))
for i, r in enumerate(rows, 1):
    fid = f'tricks-{i:03d}'
    body = r['text'].strip()
    open(f'{OUT}/tricks/{fid}.eml', 'w', encoding='utf-8').write(
        'X-PhishSquad-Note: body-only sample from IWSPA-2023 adversarial set; no original headers\n'
        'Content-Type: text/plain; charset="utf-8"\n\n' + body + '\n')
    manifest.append(dict(id=fid, source_category='tricks', source='IWSPA-2023 adversarial (ReDASers, GitHub)',
        original_file=f'adversarial_dataset.csv row {i}', date='', from_='', subject='',
        license='Cite Gholampour & Verma 2023',
        label='', label_notes=f"source label: {'phishing' if r['label'].strip()=='1' else 'legitimate'}"))

with open(f'{OUT}/manifest.csv', 'w', newline='', encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=list(manifest[0].keys())); w.writeheader(); w.writerows(manifest)
from collections import Counter
print(Counter(r['source_category'] for r in manifest))
