# PhishSquad test set — raw collection (unlabeled)

Collected Sep 30, 2026. **Not labeled yet.** The folder name is only where each email came from, not its final label.

| Folder | Count | Source | Dates |
|---|---:|---|---|
| `phishing/` | 150 | phishing_pot honeypot (rf-peixoto, GitHub) | 2023–2026, even spread |
| `spam/` | 150 | SpamAssassin public corpus (spam, spam_2) | 2001–2002 |
| `legitimate/` | 150 | SpamAssassin public corpus: 100 easy_ham + 50 hard_ham | 2002 |
| `bec/` | 0 of 150 | **Not collected — no real public BEC source exists (see below)** | — |
| `tricks/` | 275 | IWSPA-2023 adversarial set (ReDASers, GitHub) | body only |
| `darkknight25/` | 200 | darkknight25/phishing_benign_email_dataset (Hugging Face, MIT): 100 phishing + 100 benign synthetic one-liners, only 2 are BEC. Original file in `darkknight25/_source/` | synthetic |

`manifest.csv` (925 rows) lists every email with its source, original file name, date, sender and subject, an `origin` column (real / synthetic), `auto_flags` (html_body, extractor_empty_body, era_2002, no_routing_headers, body_only_or_minimal_headers), and empty labeling columns. See `LABELING_GUIDE.md` for how to fill them.

## How it was picked
- Fixed random seed, so `collect.py` reproduces the exact same selection.
- Exact duplicates and near-duplicate subjects removed (the honeypot has many repeat campaigns).
- Phishing spread evenly across 2023, 2024, 2025 and 2026.
- `hard_ham` is real legitimate marketing mail that looks spammy, included on purpose as hard cases.
- Trick emails have no headers, so each is wrapped with a note header and a blank line so the extractor can read it. The dataset's own phishing/legitimate label is kept in `label_notes`.

## Known issues to handle before benchmarking
1. **Era giveaway.** Phishing is 2023–2026 and every one has modern authentication headers (SPF/DKIM results). Spam and legitimate are from 2002 and have none. A model could tell them apart by age alone. Fix: add recent legitimate (and ideally spam) emails from our own inboxes, anonymized.
2. **Honeypot "phishing" includes plain spam.** The honeypot catches everything sent to it (casino bonuses, dating ads, reward-points promos). Some of the 150 will be relabeled as spam during labeling.
3. **18 phishing emails are HTML-only.** The current extractor only reads `text/plain`, so these come through with an empty body. Worth telling Shivoy.
4. **Old domains.** Domain-age and DNS checks on 2002 emails will return meaningless results.

## BEC gap
No real public BEC corpus is reachable. The honeypot has only about 2–3 invoice-fraud emails among 8,600, and the research BEC-2 set (279 emails) is LLM-generated and not on GitHub. The 150 BEC emails will need to be synthetic; see the chat for options.

## Licenses — do not commit these emails to the public repo
- phishing_pot: CC BY-NC 4.0 (non-commercial; attribute rf-peixoto)
- SpamAssassin public corpus: research use, see spamassassin.apache.org/old/publiccorpus/readme.html
- IWSPA-2023: cite Gholampour & Verma, "Adversarial Robustness of Phishing Email Detection Models," IWSPA 2023

Commit `collect.py` and `manifest.csv` instead, so anyone can rebuild the set.

## Rebuild
```
git clone --depth 1 https://github.com/rf-peixoto/phishing_pot.git
git clone --depth 1 https://github.com/dmitrynogin/SpamAssassin.git
git clone --depth 1 https://github.com/ReDASers/IWSPA-2023-Adversarial-Synthetic-Dataset.git
python3 collect.py
```
